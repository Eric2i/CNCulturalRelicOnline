# QandASystem-Vue

#### 介绍
知识问答子系统前端

#### 软件架构
Vue
#### 安装教程

1.  npm install


#### 使用说明

1.  npm run server
